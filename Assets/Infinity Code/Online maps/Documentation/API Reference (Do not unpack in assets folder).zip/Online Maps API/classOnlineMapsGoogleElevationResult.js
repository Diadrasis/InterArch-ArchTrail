var classOnlineMapsGoogleElevationResult =
[
    [ "elevation", "classOnlineMapsGoogleElevationResult.html#a9cc2f4009bb9bfc7d44d773aad30ca94", null ],
    [ "location", "classOnlineMapsGoogleElevationResult.html#a10eff68f23b56cbd6c9a436ce477d7c8", null ],
    [ "resolution", "classOnlineMapsGoogleElevationResult.html#a19eb00b2ba8693081f97e210c97d3ced", null ]
];
var searchData=
[
  ['vehicle_1699',['Vehicle',['../classOnlineMapsGoogleDirectionsResult_1_1Vehicle.html',1,'OnlineMapsGoogleDirectionsResult']]],
  ['vehicletype_1700',['VehicleType',['../classOnlineMapsHereRoutingAPI_1_1VehicleType.html',1,'OnlineMapsHereRoutingAPI']]]
];

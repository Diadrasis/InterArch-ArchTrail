var searchData=
[
  ['electric_2909',['electric',['../classOnlineMapsHereRoutingAPI_1_1VehicleType.html#accbe81bcfcb2e1fc2c129adc857274b7ab5a60207bdcc6a6621f1a81f00611d9d',1,'OnlineMapsHereRoutingAPI::VehicleType']]],
  ['enabled_2910',['enabled',['../classOnlineMapsHereRoutingAPI_1_1RoutingMode.html#a1e42a44e9d7e431ad109005d98c35a11aa10311459433adf322f2590a4987c423',1,'OnlineMapsHereRoutingAPI::RoutingMode']]]
];

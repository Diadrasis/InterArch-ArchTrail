var searchData=
[
  ['fare_1476',['Fare',['../classOnlineMapsGoogleDirectionsResult_1_1Fare.html',1,'OnlineMapsGoogleDirectionsResult']]],
  ['feature_1477',['Feature',['../classOnlineMapsHereRoutingAPI_1_1RoutingMode_1_1Feature.html',1,'OnlineMapsHereRoutingAPI.RoutingMode.Feature'],['../classOnlineMapsOpenRouteServiceGeocodingResult_1_1Feature.html',1,'OnlineMapsOpenRouteServiceGeocodingResult.Feature']]]
];

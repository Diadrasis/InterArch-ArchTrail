var searchData=
[
  ['data_1469',['Data',['../classOnlineMapsQQSearchResult_1_1Data.html',1,'OnlineMapsQQSearchResult']]],
  ['directionparams_1470',['DirectionParams',['../classOnlineMapsOpenRouteService_1_1DirectionParams.html',1,'OnlineMapsOpenRouteService']]]
];

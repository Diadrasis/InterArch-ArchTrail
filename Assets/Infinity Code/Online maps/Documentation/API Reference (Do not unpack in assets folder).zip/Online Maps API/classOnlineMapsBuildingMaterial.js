var classOnlineMapsBuildingMaterial =
[
    [ "roof", "classOnlineMapsBuildingMaterial.html#a0e339c12f25fd24d05a414e70b71f70c", null ],
    [ "scale", "classOnlineMapsBuildingMaterial.html#a7e00b9c8c31a6cd7cf5b0f0e1edcec6f", null ],
    [ "wall", "classOnlineMapsBuildingMaterial.html#abcd77e2c1dc32aa93df8f460c2fc8383", null ]
];